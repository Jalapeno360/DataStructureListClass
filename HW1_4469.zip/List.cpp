//
// Created by jalapeno on 1/31/2017.
//

#include "List.h"




void List::insert_front(int data)
{
    size++;
    node * p = new node;
    p->data = data;

    if (f == nullptr) {
        f = p;
        r = p;
    }
    else {

        p->next = f;
        f->prev = r;
        f = p;

    }
}
void List::insert_front(void *data) {
    node *p ;
    p = new node;
    p->ptData = data;
    size++;
    if (f == nullptr){
        f= p;
        r = p;
    }else{

        p->next = f;
        f->prev = r;
        f = p;
    }
}

void List::insert_rear(int data) {
    node *p;
    if(f == nullptr){
        p = new node;
        f = p;
        r = p;
        p->prev = nullptr;
        size++;
    }else {
        p = new node;
        r->next = p;
        r = p;
        p -> next = nullptr;
        size++;
    }
    r->data;
    r->data = data;
}

void List::insert_rear(void *data) {
    node *p;
    if(f == nullptr){
        p = new node;
        f = p;
        r = p;
        p->prev = nullptr;
        size++;
    }else {
        p = new node;
        r->next = p;
        r = p;
        p -> next = nullptr;
        size++;
    }
    r->ptData;
    r->ptData = data;
}

int List::remove_front_i() {
    node *p;
    int returnVal;
    if (f== nullptr){
        cout<<"No list made" << endl;
    }else if (f == r){
        size--;
        p = f;
        f = nullptr;
        r = nullptr;
        p->next = nullptr;
        returnVal = p->data;
        delete p;
    }else{
        size--;
        p = f;
        f = p->next;
        returnVal = p->data;
        p->next = nullptr;
        delete p;
    }

    return returnVal;
}

void * List::remove_front_p() {
    node * p;
    void * returnPointer;

    if (f == nullptr) {
        cout << "No list was made" << endl;

    } else if (f == r) {
        size--;
        p = f;
        f = nullptr;
        r = nullptr;
        p->next = nullptr;
        returnPointer = p->prev;
        delete p;
    } else {
        size--;
        p = f;
        f = p->next;
        returnPointer = p->prev;
        delete p;
    }
    return returnPointer;
}

int List::remove_rear_i() {
    node * p;
    int returnVal;
    if (f == nullptr)
    {
        cout << "No list there" << endl;
    }
    else if (f == r)
    {
        size--;
        p = f;
        f = r = nullptr;
        returnVal = p->data;
        p->next = p->prev = nullptr;
        delete p;
    }
    else {
        size--;
        p = r;
        r = r->prev;
        r->next = nullptr;
        returnVal = p->data;
        p->next = p->prev = nullptr;
        delete p;

    }
    return returnVal;

}

void * List::remove_rear_p() {
    node *  p;
    void * returnPointer;
    if (f == nullptr)
    {
        cout << "No list there" << endl;
    }
    else if (f == r)
    {
        size--;
        p = f;
        f = r = nullptr;
        returnPointer = p->ptData;
        p->next = p->prev = nullptr;
        delete p;
    }
    else {
        size--;
        p = r;
        r = r->prev;
        r->next = nullptr;
        returnPointer = p->ptData;
        p->next = p->prev = nullptr;
        delete p;

    }
    return returnPointer;
}
void List::empty() {
    int val;
    void * point;
    while(f != nullptr){

        if(f->data !=NULL || f->data == 0){
            val = remove_front_i();
            cout << "Integer " << val << " was deleted" << endl;
        }else{
            point = remove_front_p();
            cout<< "Pointer "<< point << " was deleted "<< endl;

        }

    }
    print_forward();



}

bool List::isEmpty() {
    bool returnEmpty;
    if(size == 0){
        returnEmpty = true;
    }else{
        returnEmpty = false;
    }
    return returnEmpty;
}

void List::print_forward() {
    node * p;
    p = f;
    if(p->data) {
        for (int i = size; i > 0; i--) {
            cout << "element " << i - 1 << ":" << p->data << endl;
            p = p->next;

        }
    }else{
            for (int i = size; i > 0; i--) {


                cout << p->ptData << endl;
                p = p->next;
            }
        }

}








