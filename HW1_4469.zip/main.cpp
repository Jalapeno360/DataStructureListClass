
#include "List.h"


using namespace std;

int main() {
    List a;
   // cout<<"Hi"<<endl;
    /*for (int i = 0; i < 11; i++) {
        a.insert_front(i);

    }*/
    double i = 100.15;
    void * b = &(i);
    a.insert_front(b);
    double y = 22.5;
    void * t = &y;
    a.insert_front(t);


    if(a.isEmpty()==true){
        cout<<"isEmpty function = True"<<endl;
    }else{
        cout<<"isEmpty fuction = False"<<endl;
    }
    cout<<""<<endl;
    cout<<"Print forward function"<<endl;
    a.print_forward();
    cout<<""<<endl;
    cout<<"Print reverse function"<<endl;
    // a.print_reverse();
    cout<<""<<endl;
    cout<<"Empty List function"<<endl;
    a.empty();



    return 0;
}